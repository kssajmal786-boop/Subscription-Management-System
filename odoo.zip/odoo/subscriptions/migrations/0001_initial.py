from django.db import migrations, models
import django.db.models.deletion
from decimal import Decimal


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Customer',
            fields=[
                ('customer_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('name', models.CharField(help_text='Primary contact name', max_length=255)),
                ('company_name', models.CharField(help_text='Company or Organization', max_length=255)),
                ('email', models.EmailField(help_text='Unique customer email', max_length=254, unique=True)),
                ('phone', models.CharField(blank=True, help_text='Contact phone number', max_length=30)),
                ('billing_address', models.TextField(help_text='Full street billing address')),
                ('gst_number', models.CharField(blank=True, help_text='GST / Tax Identification Number', max_length=50)),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'db_table': 'Customers',
                'ordering': ['company_name'],
            },
        ),
        migrations.CreateModel(
            name='Discount',
            fields=[
                ('discount_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('code', models.CharField(help_text='Unique promo code', max_length=50, unique=True)),
                ('name', models.CharField(max_length=150)),
                ('discount_type', models.CharField(choices=[('Fixed', 'Fixed Amount (₹)'), ('Percentage', 'Percentage (%)')], default='Percentage', max_length=20)),
                ('discount_value', models.DecimalField(decimal_places=2, help_text='Discount value in ₹ or %', max_digits=12)),
                ('min_purchase_amount', models.DecimalField(decimal_places=2, default=Decimal('0.00'), help_text='Minimum subtotal required to apply discount', max_digits=12)),
                ('min_quantity', models.PositiveIntegerField(default=1, help_text='Minimum total quantity required')),
                ('start_date', models.DateField(blank=True, null=True)),
                ('end_date', models.DateField(blank=True, null=True)),
                ('max_usage_limit', models.PositiveIntegerField(blank=True, null=True)),
                ('used_count', models.PositiveIntegerField(default=0)),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'db_table': 'Discounts',
                'ordering': ['code'],
            },
        ),
        migrations.CreateModel(
            name='Product',
            fields=[
                ('product_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=255)),
                ('product_type', models.CharField(choices=[('Service', 'Service'), ('License', 'License'), ('Consumable', 'Consumable')], default='License', max_length=50)),
                ('base_sales_price', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('cost_price', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('tax_rate', models.DecimalField(decimal_places=2, default=Decimal('18.00'), help_text='Default GST/VAT tax rate percentage (e.g. 18.00)', max_digits=5)),
                ('hsn_sac_code', models.CharField(blank=True, help_text='Harmonized System of Nomenclature code', max_length=50)),
                ('description', models.TextField(blank=True)),
                ('is_active', models.BooleanField(default=True, help_text='Soft-archive flag to preserve historical contract integrity')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'db_table': 'Products',
                'ordering': ['name'],
            },
        ),
        migrations.CreateModel(
            name='ProductVariant',
            fields=[
                ('variant_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('attribute_name', models.CharField(help_text='Attribute key (e.g. Edition, Brand, Deployment)', max_length=100)),
                ('attribute_value', models.CharField(help_text='Attribute value (e.g. Odoo Enterprise, Standard Edition, Cloud)', max_length=100)),
                ('additional_price', models.DecimalField(decimal_places=2, default=Decimal('0.00'), help_text='Price difference applied on top of the product base price', max_digits=12)),
                ('sku', models.CharField(help_text='Stock Keeping Unit / Identifier', max_length=100, unique=True)),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('product', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='variants', to='subscriptions.product')),
            ],
            options={
                'db_table': 'Product_Variants',
                'ordering': ['product', 'attribute_value'],
            },
        ),
        migrations.CreateModel(
            name='Plan',
            fields=[
                ('plan_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('plan_name', models.CharField(max_length=255)),
                ('billing_cycle', models.CharField(choices=[('Daily', 'Daily'), ('Weekly', 'Weekly'), ('Monthly', 'Monthly'), ('Quarterly', 'Quarterly'), ('Yearly', 'Yearly')], default='Monthly', max_length=50)),
                ('base_price', models.DecimalField(decimal_places=2, help_text='Cycle price override or configured base price', max_digits=12)),
                ('min_quantity', models.PositiveIntegerField(default=1, help_text='Minimum seats/units required for this plan')),
                ('default_duration', models.PositiveIntegerField(default=12, help_text='Default contract duration in billing cycles')),
                ('auto_renew_default', models.BooleanField(default=True, help_text='Default auto-renewal preference for subscriptions under this plan')),
                ('allow_pause', models.BooleanField(default=True, help_text='Allow customer or staff to pause subscriptions')),
                ('max_pause_days', models.PositiveIntegerField(default=30, help_text='Maximum days a subscription can remain paused per pause action')),
                ('grace_period_days', models.PositiveIntegerField(default=10, help_text='Grace period days before subscription is suspended on overdue invoice')),
                ('max_cycles', models.PositiveIntegerField(blank=True, help_text='Maximum total billing cycles before automatic closure (null = indefinite)', null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='plans', to='subscriptions.product')),
                ('variant', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='plans', to='subscriptions.productvariant')),
            ],
            options={
                'db_table': 'Plans',
                'ordering': ['plan_name'],
            },
        ),
        migrations.CreateModel(
            name='Subscription',
            fields=[
                ('subscription_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('subscription_number', models.CharField(db_index=True, help_text='Unique sequence identifier (e.g. QUO-2026-00001 or SUB-2026-00001)', max_length=50, unique=True)),
                ('quotation_number', models.CharField(blank=True, help_text='Original quotation reference preserved upon conversion', max_length=50, null=True)),
                ('discount_amount', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('quotation_validity_date', models.DateField(blank=True, help_text='Validity expiration date for quotations', null=True)),
                ('start_date', models.DateField(blank=True, help_text='Subscription commencement date', null=True)),
                ('next_billing_date', models.DateField(blank=True, help_text='Next scheduled recurring invoice billing date', null=True)),
                ('expiry_date', models.DateField(blank=True, help_text='Current contract expiration / renewal date', null=True)),
                ('paused_at', models.DateField(blank=True, help_text='Date when subscription was placed on pause', null=True)),
                ('total_paused_days', models.PositiveIntegerField(default=0, help_text='Cumulative paused days throughout subscription lifetime')),
                ('auto_renew', models.BooleanField(default=True, help_text='Whether subscription automatically renews upon reaching expiry_date')),
                ('status', models.CharField(choices=[('Draft', 'Draft Quotation'), ('Quotation', 'Quotation Sent'), ('Confirmed', 'Confirmed Contract'), ('Active', 'Active Subscription'), ('Paused', 'Paused'), ('Past_Due', 'Past Due'), ('Closed', 'Closed / Completed'), ('Cancelled', 'Cancelled / Rejected')], db_index=True, default='Draft', max_length=30)),
                ('notes', models.TextField(blank=True, help_text='Internal notes or customer remarks')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('applied_discount', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='subscriptions', to='subscriptions.discount')),
                ('customer', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='subscriptions', to='subscriptions.customer')),
                ('plan', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='subscriptions', to='subscriptions.plan')),
            ],
            options={
                'db_table': 'Subscriptions',
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='SubscriptionLine',
            fields=[
                ('line_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('quantity', models.PositiveIntegerField(default=1)),
                ('unit_price', models.DecimalField(decimal_places=2, help_text='Immutable snapshot unit price at quotation/confirmation', max_digits=12)),
                ('tax_rate', models.DecimalField(decimal_places=2, default=Decimal('18.00'), help_text='Immutable snapshot GST/VAT tax rate at quotation/confirmation', max_digits=5)),
                ('line_subtotal', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('tax_amount', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('line_total', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='subscription_lines', to='subscriptions.product')),
                ('subscription', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lines', to='subscriptions.subscription')),
                ('variant', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='subscription_lines', to='subscriptions.productvariant')),
            ],
            options={
                'db_table': 'Subscription_Lines',
                'ordering': ['line_id'],
            },
        ),
        migrations.CreateModel(
            name='SubscriptionHistory',
            fields=[
                ('history_id', models.BigAutoField(primary_key=True, serialize=False)),
                ('action', models.CharField(max_length=100)),
                ('old_status', models.CharField(blank=True, max_length=50)),
                ('new_status', models.CharField(max_length=50)),
                ('description', models.TextField()),
                ('performed_by', models.CharField(default='System', max_length=100)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('subscription', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='history', to='subscriptions.subscription')),
            ],
            options={
                'db_table': 'Subscription_History',
                'ordering': ['-created_at'],
            },
        ),
        migrations.AddIndex(
            model_name='customer',
            index=models.Index(fields=['is_active', 'email'], name='Customers_is_acti_2d7b41_idx'),
        ),
        migrations.AddIndex(
            model_name='product',
            index=models.Index(fields=['is_active', 'name'], name='idx_prod_active_name'),
        ),
        migrations.AddConstraint(
            model_name='productvariant',
            constraint=models.UniqueConstraint(fields=('product', 'attribute_name', 'attribute_value'), name='uq_product_attribute'),
        ),
        migrations.AddIndex(
            model_name='plan',
            index=models.Index(fields=['product', 'is_active'], name='idx_plan_prod_active'),
        ),
        migrations.AddIndex(
            model_name='subscription',
            index=models.Index(fields=['status', 'next_billing_date'], name='idx_sub_billing'),
        ),
        migrations.AddIndex(
            model_name='subscription',
            index=models.Index(fields=['customer', 'status'], name='idx_sub_cust'),
        ),
        migrations.AddIndex(
            model_name='subscriptionline',
            index=models.Index(fields=['subscription'], name='Subscriptio_subscri_7c54ef_idx'),
        ),
    ]
