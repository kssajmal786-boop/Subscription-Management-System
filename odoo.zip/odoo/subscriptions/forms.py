from django import forms
from subscriptions.models import Customer, Product, ProductVariant, Plan, Subscription, Discount


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            'name', 'product_type', 'base_sales_price', 'cost_price',
            'tax_rate', 'hsn_sac_code', 'description', 'is_active'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Software A'}),
            'product_type': forms.Select(attrs={'class': 'form-select'}),
            'base_sales_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'cost_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'tax_rate': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'hsn_sac_code': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 997331'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class ProductVariantForm(forms.ModelForm):
    class Meta:
        model = ProductVariant
        fields = [
            'product', 'attribute_name', 'attribute_value',
            'additional_price', 'sku', 'is_active'
        ]
        widgets = {
            'product': forms.Select(attrs={'class': 'form-select'}),
            'attribute_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Edition or Brand'}),
            'attribute_value': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Odoo Enterprise'}),
            'additional_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'sku': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. SOFT-A-ODOO-ENT'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class PlanForm(forms.ModelForm):
    class Meta:
        model = Plan
        fields = [
            'plan_name', 'product', 'variant', 'billing_cycle', 'base_price',
            'min_quantity', 'default_duration', 'auto_renew_default',
            'allow_pause', 'max_pause_days', 'grace_period_days', 'max_cycles', 'is_active'
        ]
        widgets = {
            'plan_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Software A Enterprise Monthly'}),
            'product': forms.Select(attrs={'class': 'form-select', 'id': 'plan_product_select'}),
            'variant': forms.Select(attrs={'class': 'form-select', 'id': 'plan_variant_select'}),
            'billing_cycle': forms.Select(attrs={'class': 'form-select'}),
            'base_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'min_quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'default_duration': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'auto_renew_default': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'allow_pause': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'max_pause_days': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'grace_period_days': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'max_cycles': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Leave empty for unlimited'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = [
            'name', 'company_name', 'email', 'phone',
            'billing_address', 'gst_number', 'is_active'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'company_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'billing_address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'gst_number': forms.TextInput(attrs={'class': 'form-control'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class PauseSubscriptionForm(forms.Form):
    pause_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )
    reason = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Seasonal suspension request'})
    )


class ResumeSubscriptionForm(forms.Form):
    resume_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )
