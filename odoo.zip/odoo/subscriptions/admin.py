from django.contrib import admin
from subscriptions.models import (
    Customer, Product, ProductVariant, Plan, Discount,
    Subscription, SubscriptionLine, SubscriptionHistory
)


class ProductVariantInline(admin.TabularInline):
    model = ProductVariant
    extra = 1
    fields = ('attribute_name', 'attribute_value', 'additional_price', 'sku', 'is_active')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'product_type', 'base_sales_price', 'cost_price', 'tax_rate', 'is_active')
    list_filter = ('product_type', 'is_active')
    search_fields = ('name', 'hsn_sac_code')
    inlines = [ProductVariantInline]


@admin.register(ProductVariant)
class ProductVariantAdmin(admin.ModelAdmin):
    list_display = ('product', 'attribute_name', 'attribute_value', 'additional_price', 'effective_price', 'sku', 'is_active')
    list_filter = ('attribute_name', 'is_active', 'product')
    search_fields = ('sku', 'attribute_value', 'product__name')


@admin.register(Plan)
class PlanAdmin(admin.ModelAdmin):
    list_display = ('plan_name', 'product', 'variant', 'billing_cycle', 'base_price', 'min_quantity', 'allow_pause', 'is_active')
    list_filter = ('billing_cycle', 'allow_pause', 'is_active')
    search_fields = ('plan_name', 'product__name')


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'name', 'email', 'phone', 'gst_number', 'is_active')
    search_fields = ('company_name', 'name', 'email', 'gst_number')
    list_filter = ('is_active',)


@admin.register(Discount)
class DiscountAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'discount_type', 'discount_value', 'min_purchase_amount', 'used_count', 'is_active')
    list_filter = ('discount_type', 'is_active')
    search_fields = ('code', 'name')


class SubscriptionLineInline(admin.TabularInline):
    model = SubscriptionLine
    extra = 0
    readonly_fields = ('line_subtotal', 'tax_amount', 'line_total')


class SubscriptionHistoryInline(admin.TabularInline):
    model = SubscriptionHistory
    extra = 0
    readonly_fields = ('action', 'old_status', 'new_status', 'description', 'performed_by', 'created_at')
    can_delete = False


@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('subscription_number', 'customer', 'plan', 'status', 'start_date', 'next_billing_date', 'total_amount')
    list_filter = ('status', 'plan__billing_cycle', 'auto_renew')
    search_fields = ('subscription_number', 'quotation_number', 'customer__company_name', 'customer__email')
    inlines = [SubscriptionLineInline, SubscriptionHistoryInline]
    readonly_fields = ('subscription_number', 'quotation_number', 'subtotal', 'total_tax', 'total_amount', 'total_paused_days')
