from django.urls import path
from subscriptions.views import (
    DashboardView, ProductListView, ProductCreateView, ProductUpdateView,
    ProductDetailView, ProductArchiveToggleView, VariantCreateView, VariantUpdateView, VariantToggleView,
    PlanListView, PlanCreateView, PlanUpdateView, PlanDetailView,
    QuotationBuilderView, QuotationTrackerView, QuotationDetailView,
    QuotationSendActionView, QuotationConfirmActionView, QuotationRejectActionView,
    SubscriptionListView, SubscriptionDetailView, SubscriptionPauseActionView,
    SubscriptionResumeActionView, SubscriptionCancelActionView
)

app_name = 'subscriptions'

urlpatterns = [
    # Dashboard
    path('', DashboardView.as_view(), name='dashboard_root'),
    path('dashboard/', DashboardView.as_view(), name='dashboard'),

    # 1. Product Catalog
    path('products/', ProductListView.as_view(), name='product_list'),
    path('products/new/', ProductCreateView.as_view(), name='product_create'),
    path('products/<int:pk>/', ProductDetailView.as_view(), name='product_detail'),
    path('products/<int:pk>/edit/', ProductUpdateView.as_view(), name='product_update'),
    path('products/<int:pk>/archive/', ProductArchiveToggleView.as_view(), name='product_archive_toggle'),

    # Variants
    path('products/<int:product_id>/variants/new/', VariantCreateView.as_view(), name='variant_create'),
    path('variants/<int:pk>/edit/', VariantUpdateView.as_view(), name='variant_update'),
    path('variants/<int:pk>/toggle/', VariantToggleView.as_view(), name='variant_toggle'),

    # 2. Subscription Plans
    path('plans/', PlanListView.as_view(), name='plan_list'),
    path('plans/new/', PlanCreateView.as_view(), name='plan_create'),
    path('plans/<int:pk>/', PlanDetailView.as_view(), name='plan_detail'),
    path('plans/<int:pk>/edit/', PlanUpdateView.as_view(), name='plan_update'),

    # 3. Quotation Builder & Tracker
    path('quotations/builder/', QuotationBuilderView.as_view(), name='quotation_builder'),
    path('quotations/', QuotationTrackerView.as_view(), name='quotation_tracker'),
    path('quotations/<int:pk>/', QuotationDetailView.as_view(), name='quotation_detail'),
    path('quotations/<int:pk>/send/', QuotationSendActionView.as_view(), name='quotation_send'),
    path('quotations/<int:pk>/confirm/', QuotationConfirmActionView.as_view(), name='quotation_confirm'),
    path('quotations/<int:pk>/reject/', QuotationRejectActionView.as_view(), name='quotation_reject'),

    # 4. Subscription Lifecycle Manager
    path('all/', SubscriptionListView.as_view(), name='subscription_list'),
    path('<int:pk>/', SubscriptionDetailView.as_view(), name='subscription_detail'),
    path('<int:pk>/pause/', SubscriptionPauseActionView.as_view(), name='subscription_pause'),
    path('<int:pk>/resume/', SubscriptionResumeActionView.as_view(), name='subscription_resume'),
    path('<int:pk>/cancel/', SubscriptionCancelActionView.as_view(), name='subscription_cancel'),
]
