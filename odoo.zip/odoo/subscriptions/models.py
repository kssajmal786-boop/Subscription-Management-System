from django.db import models
from django.utils import timezone
from decimal import Decimal
from datetime import date, timedelta


class Customer(models.Model):
    """
    Subscribify Customer profile for billing, quotations and subscriptions.
    """
    customer_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255, help_text="Primary contact name")
    company_name = models.CharField(max_length=255, help_text="Company or Organization")
    email = models.EmailField(unique=True, help_text="Unique customer email")
    phone = models.CharField(max_length=30, blank=True, help_text="Contact phone number")
    billing_address = models.TextField(help_text="Full street billing address")
    gst_number = models.CharField(max_length=50, blank=True, help_text="GST / Tax Identification Number")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Customers'
        ordering = ['company_name']
        indexes = [
            models.Index(fields=['is_active', 'email']),
        ]

    def __str__(self):
        return f"{self.company_name} ({self.name})"


class Product(models.Model):
    """
    Core Product / Service catalog item.
    """
    class ProductType(models.TextChoices):
        SERVICE = 'Service', 'Service'
        LICENSE = 'License', 'License'
        CONSUMABLE = 'Consumable', 'Consumable'

    product_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255)
    product_type = models.CharField(
        max_length=50,
        choices=ProductType.choices,
        default=ProductType.LICENSE
    )
    base_sales_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    cost_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('18.00'),
        help_text="Default GST/VAT tax rate percentage (e.g. 18.00)"
    )
    hsn_sac_code = models.CharField(max_length=50, blank=True, help_text="Harmonized System of Nomenclature code")
    description = models.TextField(blank=True)
    is_active = models.BooleanField(
        default=True,
        help_text="Soft-archive flag to preserve historical contract integrity"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Products'
        ordering = ['name']
        indexes = [
            models.Index(fields=['is_active', 'name'], name='idx_prod_active_name'),
        ]

    def __str__(self):
        return f"{self.name} [{self.product_type}] (₹{self.base_sales_price})"

    @property
    def active_variants_count(self):
        return self.variants.filter(is_active=True).count()


class ProductVariant(models.Model):
    """
    Product attribute variant with price differentials and SKU tracking.
    """
    variant_id = models.BigAutoField(primary_key=True)
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='variants'
    )
    attribute_name = models.CharField(
        max_length=100,
        help_text="Attribute key (e.g. Edition, Brand, Deployment)"
    )
    attribute_value = models.CharField(
        max_length=100,
        help_text="Attribute value (e.g. Odoo Enterprise, Standard Edition, Cloud)"
    )
    additional_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text="Price difference applied on top of the product base price"
    )
    sku = models.CharField(max_length=100, unique=True, help_text="Stock Keeping Unit / Identifier")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Product_Variants'
        ordering = ['product', 'attribute_value']
        constraints = [
            models.UniqueConstraint(
                fields=['product', 'attribute_name', 'attribute_value'],
                name='uq_product_attribute'
            )
        ]

    def __str__(self):
        return f"{self.product.name} - {self.attribute_value} (SKU: {self.sku})"

    @property
    def effective_price(self):
        """Calculates total unit price: base product price + variant differential"""
        return self.product.base_sales_price + self.additional_price


class Plan(models.Model):
    """
    Reusable subscription plan templates linking products and variants to billing cycles.
    """
    class BillingCycle(models.TextChoices):
        DAILY = 'Daily', 'Daily'
        WEEKLY = 'Weekly', 'Weekly'
        MONTHLY = 'Monthly', 'Monthly'
        QUARTERLY = 'Quarterly', 'Quarterly'
        YEARLY = 'Yearly', 'Yearly'

    plan_id = models.BigAutoField(primary_key=True)
    plan_name = models.CharField(max_length=255)
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name='plans'
    )
    variant = models.ForeignKey(
        ProductVariant,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='plans'
    )
    billing_cycle = models.CharField(
        max_length=50,
        choices=BillingCycle.choices,
        default=BillingCycle.MONTHLY
    )
    base_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        help_text="Cycle price override or configured base price"
    )
    min_quantity = models.PositiveIntegerField(
        default=1,
        help_text="Minimum seats/units required for this plan"
    )
    default_duration = models.PositiveIntegerField(
        default=12,
        help_text="Default contract duration in billing cycles"
    )
    auto_renew_default = models.BooleanField(
        default=True,
        help_text="Default auto-renewal preference for subscriptions under this plan"
    )
    allow_pause = models.BooleanField(
        default=True,
        help_text="Allow customer or staff to pause subscriptions"
    )
    max_pause_days = models.PositiveIntegerField(
        default=30,
        help_text="Maximum days a subscription can remain paused per pause action"
    )
    grace_period_days = models.PositiveIntegerField(
        default=10,
        help_text="Grace period days before subscription is suspended on overdue invoice"
    )
    max_cycles = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Maximum total billing cycles before automatic closure (null = indefinite)"
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Plans'
        ordering = ['plan_name']
        indexes = [
            models.Index(fields=['product', 'is_active'], name='idx_plan_prod_active'),
        ]

    def __str__(self):
        variant_label = f" ({self.variant.attribute_value})" if self.variant else ""
        return f"{self.plan_name} - {self.product.name}{variant_label} [{self.billing_cycle}] @ ₹{self.base_price}"


class Discount(models.Model):
    """
    Conditional discount rules for promotional campaigns and volume orders.
    """
    class DiscountType(models.TextChoices):
        FIXED = 'Fixed', 'Fixed Amount (₹)'
        PERCENTAGE = 'Percentage', 'Percentage (%)'

    discount_id = models.BigAutoField(primary_key=True)
    code = models.CharField(max_length=50, unique=True, help_text="Unique promo code")
    name = models.CharField(max_length=150)
    discount_type = models.CharField(
        max_length=20,
        choices=DiscountType.choices,
        default=DiscountType.PERCENTAGE
    )
    discount_value = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        help_text="Discount value in ₹ or %"
    )
    min_purchase_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text="Minimum subtotal required to apply discount"
    )
    min_quantity = models.PositiveIntegerField(
        default=1,
        help_text="Minimum total quantity required"
    )
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    max_usage_limit = models.PositiveIntegerField(null=True, blank=True)
    used_count = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'Discounts'
        ordering = ['code']

    def __str__(self):
        val_str = f"₹{self.discount_value}" if self.discount_type == self.DiscountType.FIXED else f"{self.discount_value}%"
        return f"{self.code} - {self.name} ({val_str})"

    def is_valid_now(self):
        today = timezone.localdate() if timezone.is_aware(timezone.now()) else date.today()
        if not self.is_active:
            return False
        if self.start_date and today < self.start_date:
            return False
        if self.end_date and today > self.end_date:
            return False
        if self.max_usage_limit and self.used_count >= self.max_usage_limit:
            return False
        return True

    def calculate_discount(self, subtotal, quantity=1):
        if not self.is_valid_now():
            return Decimal('0.00')
        if subtotal < self.min_purchase_amount or quantity < self.min_quantity:
            return Decimal('0.00')

        if self.discount_type == self.DiscountType.PERCENTAGE:
            disc = (subtotal * self.discount_value) / Decimal('100.00')
            return disc.quantize(Decimal('0.01'))
        else:
            return min(self.discount_value, subtotal).quantize(Decimal('0.01'))


class Subscription(models.Model):
    """
    Unified Lifecycle model for Quotations and Subscriptions.
    Lifecycle: Draft -> Quotation -> Confirmed -> Active <-> Paused / Past Due -> Closed / Cancelled
    """
    class Status(models.TextChoices):
        DRAFT = 'Draft', 'Draft Quotation'
        QUOTATION = 'Quotation', 'Quotation Sent'
        CONFIRMED = 'Confirmed', 'Confirmed Contract'
        ACTIVE = 'Active', 'Active Subscription'
        PAUSED = 'Paused', 'Paused'
        PAST_DUE = 'Past_Due', 'Past Due'
        CLOSED = 'Closed', 'Closed / Completed'
        CANCELLED = 'Cancelled', 'Cancelled / Rejected'

    subscription_id = models.BigAutoField(primary_key=True)
    subscription_number = models.CharField(
        max_length=50,
        unique=True,
        db_index=True,
        help_text="Unique sequence identifier (e.g. QUO-2026-00001 or SUB-2026-00001)"
    )
    quotation_number = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        help_text="Original quotation reference preserved upon conversion"
    )
    customer = models.ForeignKey(
        Customer,
        on_delete=models.PROTECT,
        related_name='subscriptions'
    )
    plan = models.ForeignKey(
        Plan,
        on_delete=models.PROTECT,
        related_name='subscriptions'
    )
    applied_discount = models.ForeignKey(
        Discount,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='subscriptions'
    )
    discount_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )
    quotation_validity_date = models.DateField(
        null=True,
        blank=True,
        help_text="Validity expiration date for quotations"
    )
    start_date = models.DateField(
        null=True,
        blank=True,
        help_text="Subscription commencement date"
    )
    next_billing_date = models.DateField(
        null=True,
        blank=True,
        help_text="Next scheduled recurring invoice billing date"
    )
    expiry_date = models.DateField(
        null=True,
        blank=True,
        help_text="Current contract expiration / renewal date"
    )
    paused_at = models.DateField(
        null=True,
        blank=True,
        help_text="Date when subscription was placed on pause"
    )
    total_paused_days = models.PositiveIntegerField(
        default=0,
        help_text="Cumulative paused days throughout subscription lifetime"
    )
    auto_renew = models.BooleanField(
        default=True,
        help_text="Whether subscription automatically renews upon reaching expiry_date"
    )
    status = models.CharField(
        max_length=30,
        choices=Status.choices,
        default=Status.DRAFT,
        db_index=True
    )
    notes = models.TextField(blank=True, help_text="Internal notes or customer remarks")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Subscriptions'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', 'next_billing_date'], name='idx_sub_billing'),
            models.Index(fields=['customer', 'status'], name='idx_sub_cust'),
        ]

    def __str__(self):
        return f"{self.subscription_number} - {self.customer.company_name} [{self.status}]"

    # Financial & Calculations Properties
    @property
    def subtotal(self):
        """Sum of line item subtotals (quantity * unit_price)"""
        total = sum(line.line_subtotal for line in self.lines.all())
        return Decimal(total).quantize(Decimal('0.01'))

    @property
    def total_tax(self):
        """Sum of line item tax amounts"""
        total = sum(line.tax_amount for line in self.lines.all())
        return Decimal(total).quantize(Decimal('0.01'))

    @property
    def total_amount(self):
        """Subtotal - discount_amount + total_tax"""
        sub = self.subtotal
        disc = self.discount_amount or Decimal('0.00')
        tax = self.total_tax
        grand_total = max(Decimal('0.00'), sub - disc) + tax
        return grand_total.quantize(Decimal('0.01'))

    @property
    def is_quotation(self):
        return self.status in [self.Status.DRAFT, self.Status.QUOTATION]

    @property
    def is_active_subscription(self):
        return self.status in [self.Status.ACTIVE, self.Status.PAUSED, self.Status.PAST_DUE]


class SubscriptionLine(models.Model):
    """
    Itemized products/variants attached to a quotation or subscription.
    CRITICAL: Captures price snapshot (unit_price, tax_rate) at quotation/confirmation
    to guarantee contract immutability against future catalog changes.
    """
    line_id = models.BigAutoField(primary_key=True)
    subscription = models.ForeignKey(
        Subscription,
        on_delete=models.CASCADE,
        related_name='lines'
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name='subscription_lines'
    )
    variant = models.ForeignKey(
        ProductVariant,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='subscription_lines'
    )
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        help_text="Immutable snapshot unit price at quotation/confirmation"
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('18.00'),
        help_text="Immutable snapshot GST/VAT tax rate at quotation/confirmation"
    )
    line_subtotal = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )
    tax_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )
    line_total = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Subscription_Lines'
        ordering = ['line_id']
        indexes = [
            models.Index(fields=['subscription']),
        ]

    def save(self, *args, **kwargs):
        # Auto-compute line totals
        self.line_subtotal = (Decimal(self.quantity) * Decimal(self.unit_price)).quantize(Decimal('0.01'))
        self.tax_amount = (self.line_subtotal * (Decimal(self.tax_rate) / Decimal('100.00'))).quantize(Decimal('0.01'))
        self.line_total = (self.line_subtotal + self.tax_amount).quantize(Decimal('0.01'))
        super().save(*args, **kwargs)

    def __str__(self):
        variant_str = f" - {self.variant.attribute_value}" if self.variant else ""
        return f"{self.product.name}{variant_str} (Qty: {self.quantity}) @ ₹{self.unit_price}"


class SubscriptionHistory(models.Model):
    """
    Immutable audit trail for tracking quotation and subscription lifecycle actions,
    status changes, pause/resume shifts, and operational notes.
    """
    history_id = models.BigAutoField(primary_key=True)
    subscription = models.ForeignKey(
        Subscription,
        on_delete=models.CASCADE,
        related_name='history'
    )
    action = models.CharField(max_length=100)
    old_status = models.CharField(max_length=50, blank=True)
    new_status = models.CharField(max_length=50)
    description = models.TextField()
    performed_by = models.CharField(max_length=100, default='System')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'Subscription_History'
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.created_at.strftime('%Y-%m-%d %H:%M')}] {self.subscription.subscription_number} - {self.action}"
