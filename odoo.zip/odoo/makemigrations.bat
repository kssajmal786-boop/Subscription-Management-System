@echo off
.venv\Scripts\python.exe manage.py makemigrations subscriptions
pause
