@echo off
uv pip install -r requirements.txt --python .venv\Scripts\python.exe
