@echo off
echo ========================================================
echo   Running Subscribify Core Test Suite
echo ========================================================
echo.
.venv\Scripts\python.exe manage.py test subscriptions.tests -v 2
