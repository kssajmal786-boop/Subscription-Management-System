"""
Subscribify Root URL Configuration
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', RedirectView.as_view(url='/subscriptions/dashboard/', permanent=False)),
    path('subscriptions/', include('subscriptions.urls')),
    path('api/v1/', include('subscriptions.api_urls')),
]
