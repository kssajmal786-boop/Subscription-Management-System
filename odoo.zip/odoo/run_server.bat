@echo off
echo ========================================================
echo   Launching Subscribify Core Development Server
echo   URL: http://127.0.0.1:8000/
echo   Admin: http://127.0.0.1:8000/admin/
echo   REST API: http://127.0.0.1:8000/api/v1/
echo ========================================================
echo.
.venv\Scripts\python.exe manage.py runserver 0.0.0.0:8000
