@echo off
echo ========================================================
echo   Subscribify - Environment Setup & Dependency Install
echo ========================================================
echo.

IF NOT EXIST .venv (
    echo Creating Python 3.12 virtual environment using uv...
    uv venv --python 3.12 .venv
) ELSE (
    echo Virtual environment .venv already exists.
)

echo.
echo Installing dependencies from requirements.txt...
uv pip install -r requirements.txt --python .venv\Scripts\python.exe

echo.
echo Running database migrations...
.venv\Scripts\python.exe manage.py migrate

echo.
echo Seeding demo data (Brightloop Software scenario)...
.venv\Scripts\python.exe manage.py seed_demo_data

echo.
echo ========================================================
echo   Subscribify Setup Complete!
echo   To launch the server, run: run_server.bat
echo ========================================================
pause
