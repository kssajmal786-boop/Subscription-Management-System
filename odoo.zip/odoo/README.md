# Subscribify – Product Catalog, Subscription Plans & Subscription Lifecycle Management

> **Enterprise-grade Subscription & Recurring Billing Management Engine** built with Python 3.12, Django 5.x, Django REST Framework, MySQL 8.0 (with SQLite auto-fallback), and modern Bootstrap 5 UI.

---

## 1. Architectural & Functional Overview

Subscribify delivers a complete Quote-to-Cash and Subscription Lifecycle Management core. It unifies pre-sales quoting, immutable contract price snapshotting, multi-variant catalog pricing, flexible recurring billing templates, and pause/resume date-shift calculations into a single cohesive system.

### Key Highlights
- **Product & Multi-Variant Catalog**: Configure base products (License, Service, Consumable), GST tax rates (e.g., 18%), HSN/SAC codes, soft-archiving (`is_active` flag to preserve historical contracts), and dynamic product variants with price differentials (e.g. *Software A – Odoo Enterprise at ₹2,560* vs *Standard at ₹2,000*).
- **Subscription Plan Engine**: Define reusable billing templates supporting **Daily, Weekly, Monthly, Quarterly, and Yearly** cycles, configurable pause allowances, max pause durations, auto-renewal preferences, and overdue grace periods.
- **Interactive Quotation Builder**: Dynamic browser UI for adding itemized lines, live subtotal, GST/tax calculation, promotional discount code validation, validity date scheduling, and sequence generation (`QUO-YYYY-XXXXX`).
- **Unified Lifecycle State Machine**:
  $$\text{Draft} \longrightarrow \text{Quotation Sent} \longrightarrow \text{Confirmed} \longrightarrow \text{Active} \longleftrightarrow \text{Paused / Past Due} \longrightarrow \text{Closed / Cancelled}$$
- **Contract Price Snapshotting**: Freezes agreed unit prices and tax rates in `Subscription_Lines` upon confirmation. Subsequent catalog price increases never tamper with active contracts.
- **Pause & Resume Date-Shift Math**: When a subscription is paused on $T_{\text{pause}}$ and resumed on $T_{\text{resume}}$, both `next_billing_date` and `expiry_date` shift forward by $\Delta_{\text{pause}} = T_{\text{resume}} - T_{\text{pause}}$ days. Automated billing skips paused contracts so customers are never billed during pause periods.
- **Module Integration APIs**: Exposes full REST API endpoints with Django REST Framework, including a specialized `/api/v1/subscriptions/due-billing/` query for the asynchronous daily invoicing worker (Module 5).

---

## 2. Directory Structure

```text
d:\odoo\
├── manage.py                          # Django management script
├── pyproject.toml                     # Project dependencies & metadata
├── requirements.txt                   # Frozen requirements
├── setup_environment.bat              # One-click environment bootstrap & migrations
├── run_server.bat                     # Launch development server
├── run_tests.bat                      # Execute test suite
├── makemigrations.bat                 # Django makemigrations helper
├── migrate.bat                        # Django migrate helper
├── seed_data.bat                      # Demo data seed script
│
├── subscribify/                       # Project Configuration Root
│   ├── __init__.py                    # PyMySQL MySQLdb hook
│   ├── settings.py                    # MySQL 8.0 + SQLite fallback, DRF, templates
│   ├── urls.py                        # Root URL routing (Web + API v1)
│   ├── wsgi.py                        # WSGI entry point
│   └── asgi.py                        # ASGI entry point
│
└── subscriptions/                     # Core Subscriptions Application
    ├── admin.py                       # Django Admin models & inline configurations
    ├── apps.py                        # App metadata
    ├── models.py                      # Customer, Product, Variant, Plan, Discount, Subscription, Line, History
    ├── serializers.py                 # DRF Serializers & calculation schemas
    ├── forms.py                       # Django Forms for Web UI
    ├── urls.py                        # Web view URL routing
    ├── api_urls.py                    # REST API ViewSet router
    │
    ├── services/                      # Enterprise Business Logic Services
    │   ├── lifecycle_service.py       # Atomic state transitions with row-level locks
    │   ├── pause_resume_service.py    # Pause/resume date-shift math and validation
    │   ├── quotation_service.py       # Quote builder calculations, taxes, discounts, sequence IDs
    │   └── snapshot_service.py        # Contract price & tax rate snapshot immutability
    │
    ├── views/                         # Controllers
    │   ├── web_views.py               # 10 Web UI Screens & action handlers
    │   └── api_views.py               # DRF ViewSets (Products, Variants, Plans, Subscriptions)
    │
    ├── management/commands/           # CLI Commands
    │   └── seed_demo_data.py          # Brightloop Software scenario demo seeder
    │
    ├── static/subscriptions/          # Static Assets
    │   ├── css/custom.css             # Sleek modern dashboard styling, cards, status badges
    │   └── js/
    │       ├── quotation_builder.js   # Dynamic line item adder & real-time client-side calculation
    │       └── subscription_actions.js# Real-time date-shift preview for pause/resume modals
    │
    ├── templates/subscriptions/       # Responsive Bootstrap 5 HTML Templates
    │   ├── base.html                  # Base layout with navbar, alerts & footer
    │   ├── dashboard.html             # Executive & Operations dashboard with KPI cards
    │   ├── products/                  # Product & Variant management screens
    │   │   ├── product_list.html
    │   │   ├── product_form.html
    │   │   ├── product_detail.html
    │   │   └── variant_form.html
    │   ├── plans/                     # Subscription plan templates
    │   │   ├── plan_list.html
    │   │   ├── plan_form.html
    │   │   └── plan_detail.html
    │   ├── quotations/                # Quotation builder & pipeline tracker
    │   │   ├── quotation_builder.html
    │   │   ├── quotation_tracker.html
    │   │   └── quotation_detail.html
    │   └── subscriptions/             # Subscription lifecycle manager
    │       ├── subscription_list.html
    │       └── subscription_detail.html
    │
    ├── migrations/                    # Database Migrations
    │   └── 0001_initial.py            # Initial schema migration
    │
    └── tests/                         # Comprehensive Unit & Integration Test Suite
        ├── test_models.py             # Product, variant, plan, discount tests
        ├── test_quotations.py         # Subtotals, tax rates, min quantity, quote creation
        ├── test_subscriptions.py      # State conversions, sequence upgrade (QUO -> SUB)
        ├── test_snapshots.py          # Contract immutability against catalog price changes
        ├── test_pause_resume.py       # Exact date-shift math calculations & validations
        └── test_api.py                # REST API endpoints & due-billing integration query
```

---

## 3. Database Design & Relational Schema

| Model | Table Name | Key Fields | Purpose |
| :--- | :--- | :--- | :--- |
| **`Customer`** | `Customers` | `customer_id`, `name`, `company_name`, `email`, `phone`, `billing_address`, `gst_number`, `is_active` | Customer profile for quote proposals and billing. |
| **`Product`** | `Products` | `product_id`, `name`, `product_type`, `base_sales_price`, `cost_price`, `tax_rate`, `hsn_sac_code`, `is_active` | Recurring catalog items with GST/tax configuration and soft-archive protection. |
| **`ProductVariant`** | `Product_Variants` | `variant_id`, `product_id`, `attribute_name`, `attribute_value`, `additional_price`, `sku`, `is_active` | Price differentials and SKU variants (`base_price + additional_price`). |
| **`Plan`** | `Plans` | `plan_id`, `plan_name`, `product_id`, `variant_id`, `billing_cycle`, `base_price`, `min_quantity`, `default_duration`, `allow_pause`, `max_pause_days`, `grace_period_days`, `auto_renew_default`, `max_cycles`, `is_active` | Reusable billing templates (Daily, Weekly, Monthly, Quarterly, Yearly). |
| **`Discount`** | `Discounts` | `discount_id`, `code`, `name`, `discount_type`, `discount_value`, `min_purchase_amount`, `min_quantity`, `max_usage_limit`, `used_count`, `is_active` | Conditional discount engine (Fixed ₹ or % with spend/qty rules). |
| **`Subscription`** | `Subscriptions` | `subscription_id`, `subscription_number`, `quotation_number`, `customer_id`, `plan_id`, `applied_discount_id`, `discount_amount`, `quotation_validity_date`, `start_date`, `next_billing_date`, `expiry_date`, `paused_at`, `total_paused_days`, `auto_renew`, `status`, `notes` | Unified quote-to-subscription contract lifecycle model. |
| **`SubscriptionLine`** | `Subscription_Lines` | `line_id`, `subscription_id`, `product_id`, `variant_id`, `quantity`, `unit_price`, `tax_rate`, `line_subtotal`, `tax_amount`, `line_total` | **Immutable contract price snapshot lines**. |
| **`SubscriptionHistory`** | `Subscription_History` | `history_id`, `subscription_id`, `action`, `old_status`, `new_status`, `description`, `performed_by`, `created_at` | Non-repudiation audit trail for lifecycle transitions and date shifts. |

---

## 4. Business Logic & Core Algorithms

### A. Price Snapshot Immutability
When a quotation is drafted or converted into an active subscription:
1. `SnapshotService.get_effective_price_and_tax(product, variant)` evaluates catalog pricing:
   $$\text{Unit Price} = \text{Product.base\_sales\_price} + \text{Variant.additional\_price}$$
2. The values are stored into `SubscriptionLine.unit_price` and `SubscriptionLine.tax_rate`.
3. If an administrator later raises the product's catalog price from ₹2,000 to ₹3,500 or updates tax rates, existing subscriptions retain their original snapshot unit prices and continue billing at the agreed rate.

### B. Pause & Resume Date-Shift Math
1. **Pausing**:
   - Condition: Subscription must be `Active` and `plan.allow_pause == True`.
   - `Subscription.paused_at = pause_date` (defaults to today).
   - `Subscription.status = 'Paused'`.
   - Recurring billing crons skip paused subscriptions.
2. **Resuming**:
   - Condition: Subscription must be `Paused` and `resume_date >= paused_at`.
   - Calculate paused duration:
     $$\Delta_{\text{pause}} = \text{resume\_date} - \text{paused\_at} \quad (\text{days})$$
   - Shift next billing date forward:
     $$\text{next\_billing\_date}_{\text{new}} = \text{next\_billing\_date}_{\text{old}} + \Delta_{\text{pause}}$$
   - Shift contract expiration date forward:
     $$\text{expiry\_date}_{\text{new}} = \text{expiry\_date}_{\text{old}} + \Delta_{\text{pause}}$$
   - Accumulate total pause days: $\text{total\_paused\_days} += \Delta_{\text{pause}}$.
   - Clear `paused_at = None` and restore `status = 'Active'`.
   - Records an audit log in `SubscriptionHistory` documenting the exact date shift.

---

## 5. REST API Documentation (For Integration with Other Modules)

All endpoints return JSON and accept standard DRF pagination (`?page=1`).

### Base URL: `/api/v1/`

#### 1. Products & Variants
- `GET /api/v1/products/` - List products (filter: `?is_active=true`, `?product_type=License`, `?search=Software`)
- `POST /api/v1/products/` - Create a product
- `GET /api/v1/products/{id}/` - Retrieve product details with nested variants
- `POST /api/v1/products/{id}/archive/` - Soft-archive a product
- `POST /api/v1/products/{id}/restore/` - Restore an archived product
- `POST /api/v1/variants/` - Create product variant with `additional_price` and `sku`
- `POST /api/v1/variants/{id}/toggle_active/` - Toggle variant activation

#### 2. Subscription Plans
- `GET /api/v1/plans/` - List plans (filter: `?billing_cycle=Monthly`, `?product_id=1`)
- `POST /api/v1/plans/` - Create plan template

#### 3. Quotation & Subscription Lifecycle
- `POST /api/v1/subscriptions/` - Draft a new quotation with line items:
  ```json
  {
    "customer_id": 1,
    "plan_id": 1,
    "lines": [
      { "product_id": 1, "variant_id": 1, "quantity": 5 }
    ],
    "validity_days": 15,
    "discount_code": "WELCOME10",
    "notes": "Q4 Enterprise license proposal"
  }
  ```
- `POST /api/v1/subscriptions/calculate/` - Stateless real-time quote preview (computes subtotal, tax, discount, grand total)
- `POST /api/v1/subscriptions/{id}/send/` - Transition Draft &rarr; Quotation Sent
- `POST /api/v1/subscriptions/{id}/confirm/` - Accept & Confirm Quotation &rarr; Upgrades to Subscription (`QUO-...` &rarr; `SUB-...`), snapshots line prices, sets billing dates
- `POST /api/v1/subscriptions/{id}/activate/` - Activate confirmed contract &rarr; Recurring billing active
- `POST /api/v1/subscriptions/{id}/pause/` - Pause subscription: `{ "pause_date": "2026-11-01", "reason": "Maintenance" }`
- `POST /api/v1/subscriptions/{id}/resume/` - Resume subscription with date-shift: `{ "resume_date": "2026-11-15" }`
- `POST /api/v1/subscriptions/{id}/cancel/` - Cancel subscription: `{ "reason": "Customer request" }`

#### 4. Automated Daily Billing Integration Hook (For Module 5 - Invoicing)
- `GET /api/v1/subscriptions/due-billing/`
  - Returns all `Active` subscriptions where `next_billing_date <= TODAY`.
  - The Celery Beat automated daily billing task consumes this endpoint to generate idempotent invoices.

---

## 6. How to Run the Application & Test Suite

### Option A: Using Windows Helper Scripts (Recommended)
1. **One-click Setup & Seed Data**:
   ```cmd
   setup_environment.bat
   ```
2. **Start Development Server**:
   ```cmd
   run_server.bat
   ```
   Open **http://127.0.0.1:8000/** in your browser.

3. **Run All Unit Tests**:
   ```cmd
   run_tests.bat
   ```

### Option B: Using the Virtual Environment Directly in PowerShell
```powershell
# 1. Activate virtual environment
.venv\Scripts\Activate.ps1

# 2. Run migrations
python manage.py migrate

# 3. Seed Brightloop Software demo scenario
python manage.py seed_demo_data

# 4. Run tests
python manage.py test subscriptions.tests -v 2

# 5. Start server
python manage.py runserver 0.0.0.0:8000
```

---

## 7. Database Configuration (MySQL 8.0 & SQLite Fallback)

Subscribify is configured in `subscribify/settings.py` to seamlessly support both **MySQL 8.0** and **SQLite**:
- **Default / Development**: Defaults to SQLite out-of-the-box so tests and local UI run with zero manual database setup.
- **MySQL 8.0 Production Setup**:
  To connect to MySQL 8.0, set the environment variables:
  ```powershell
  $env:USE_MYSQL="True"
  $env:DB_NAME="subscribify_db"
  $env:DB_USER="root"
  $env:DB_PASSWORD="your_password"
  $env:DB_HOST="127.0.0.1"
  $env:DB_PORT="3306"
  ```
  Then run `python manage.py migrate`. PyMySQL is configured automatically.

---

## 8. Verification & Test Suite Summary

The unit test suite in `subscriptions/tests/` covers:
1. `test_models.py`: Product catalog, soft-archiving, variant effective pricing (`₹2,000 + ₹560 = ₹2,560`), plan constraints, and discount calculations.
2. `test_quotations.py`: Subtotal, GST (18%), discount codes (`WELCOME10`), minimum plan quantity validation, sequence generation (`QUO-YYYY-XXXXX`), status transition to Quotation Sent.
3. `test_subscriptions.py`: Quotation acceptance and conversion into confirmed subscription, sequence upgrade (`QUO-...` &rarr; `SUB-...`), contract expiration date math across billing cycles, atomic discount usage incrementing.
4. `test_snapshots.py`: **Contract immutability test** — proves that modifying `Product.base_sales_price` or `ProductVariant.additional_price` after confirmation has zero effect on existing subscription lines or totals.
5. `test_pause_resume.py`: Exact date-shift math verification — proves that pausing for 15 days shifts both `next_billing_date` and `expiry_date` forward by exactly 15 days, increments `total_paused_days`, clears `paused_at`, and restores `Active` status.
6. `test_api.py`: Comprehensive REST API verification including product management, quotation creation, quotation calculation preview, lifecycle actions (send, confirm, activate, pause, resume, cancel), and the `/api/v1/subscriptions/due-billing/` endpoint.
