@echo off
.venv\Scripts\python.exe manage.py seed_demo_data
pause
